// deleteitem.js

function deleteEmployee() {
    var ei = document.getElementById('employeeId').value;
    const employeeId = Number(ei);

    // Validate employee ID
    if (!ei.trim()) {
        alert('Please enter Employee ID to delete.');
        return;
    }

    var apiUrl = 'https://a5r4kzt7n8.execute-api.us-east-1.amazonaws.com/employeemanagement/employee';

    // Assuming you are using the fetch API
    fetch(apiUrl, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            // You may need to include additional headers, such as authorization headers
        },
        // You can include a request body if required by your API
        body: JSON.stringify({ employeeId }),
    })
        .then(response => {
            if (response.ok) {
                // Handle successful deletion
                console.log('Employee deleted successfully');
                alert('Employee deleted successfully');
                window.location.href = 'index.html';

            } else {
                // Handle deletion failure
                alert('Employee record not exist....try again!');
                window.location.href = 'deleteEmployee.html';
            }
        })
        .catch(error => {
            // Handle network or other errors
            console.error('Error during deletion:', error);
        });
}

function goBack() {
    window.location.href = 'index.html';
}
