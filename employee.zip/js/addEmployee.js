const apiEndpoint = 'https://a5r4kzt7n8.execute-api.us-east-1.amazonaws.com/employeemanagement/employee';
const apiEndpointcheck = 'https://a5r4kzt7n8.execute-api.us-east-1.amazonaws.com/employeemanagement/employee?';

function addEmployee() {
  const employeeIdInput = document.getElementById('employeeId');
  const employeeNameInput = document.getElementById('employeeName');
  const employeeRoleInput = document.getElementById('employeeRole');

  const employeeIdValue = employeeIdInput.value.trim();
  const EmployeeName = employeeNameInput.value.trim();
  const EmployeeRole = employeeRoleInput.value.trim();

  // Validate employee ID
  if (!/^\d{7}$/.test(employeeIdValue) || !employeeIdValue.startsWith('811')) {
    alert('Please enter a valid 7-digit Employee ID starting with "811"');
    employeeIdInput.focus();
    return;
  }
  if (!/^[a-zA-Z\s]+$/.test(EmployeeName) || !/^[a-zA-Z\s]+$/.test(EmployeeRole)) {
    alert('Employee name and role cannot be empty and should contain only alphabets');
    return;
  }

  // Check if the employee ID already exists
  checkEmployeeExistence(employeeIdValue, () => {
    // If the employee ID does not exist, proceed to add the employee
    const newEmployee = {
      employeeId: Number(employeeIdValue),
      EmployeeName,
      EmployeeRole,
    };

    fetch(apiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newEmployee),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log('Employee added successfully:', data);
        alert('Employee added successfully!');
        window.location.href = 'index.html';
      })
      .catch(error => {
        console.error('Error adding employee:', error);
        alert('Error adding employee. Please try again.');
        window.location.href = 'add_employee.html';
      });
  });
}




function goBack() {
  window.location.href = 'index.html';
}
function checkEmployeeExistence(employeeId, callback) {
  // Check if the employee ID already exists
  fetch(`${apiEndpointcheck}employeeId=${employeeId}`)
    .then(response => {
      if (response.status === 200) {
        // Employee ID found, parse the JSON response
        return response.json();
      } else if (response.status === 404) {
        // Employee ID not found, return null
        return null;
      } else {
        // Handle other response statuses
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
    })
    .then(existingEmployee => {
      // If existingEmployee is not null, the employee ID already exists
      if (existingEmployee !== null && Object.keys(existingEmployee).length !== 0) {
        alert('Employee ID already exists. Please try another.');
      } else {
        // If the employee ID does not exist, invoke the callback function
        callback();
      }
    })
    .catch(error => {
      // Log the error to the console
      console.error('Error checking employee existence:', error);
      // Display a user-friendly error message
      alert('Error checking employee existence. Please try again.');
    });
}


