// searchEmployee.js

const apiEndpoint = 'https://a5r4kzt7n8.execute-api.us-east-1.amazonaws.com/employeemanagement/employee?';

function searchEmployee() {
    const employeeId = document.getElementById('employeeId').value.trim();

    // Validate employee ID
    if (!employeeId) {
        alert('Please enter an Employee ID to search.');
        return;
    }

    const searchUrl = `${apiEndpoint}employeeId=${employeeId}`;
    console.log(searchUrl)

    fetch(searchUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // Parse response as JSON
        })
        .then(data => {
            console.log('Search result:', data);
            displaySearchResult(data);
        })
        .catch(error => {
            console.error('Error searching for employee:', error);
            alert('Invalid Employee Id. Please try again.');
            goBack();
        });
}

function displaySearchResult(searchResult) {
    const container = document.querySelector('.container');
    container.innerHTML = ''; // Clear existing content

    if (searchResult && searchResult.employeeId) {
        // Employee found, display in a table
        const table = document.createElement('table');
        table.style.width = '100%';
        table.style.borderCollapse = 'collapse';

        // Add some styling to the table headers
        const thStyle = 'border: 1px solid #ddd; padding: 8px; text-align: left; background-color: #f2f2f2;';

        table.innerHTML = `
            <tr>
                <th style="${thStyle}">Employee ID</th>
                <th style="${thStyle}">Employee Name</th>
                <th style="${thStyle}">Employee Role</th>
            </tr>
            <tr>
                <td style="${thStyle}">${searchResult.employeeId || ''}</td>
                <td style="${thStyle}">${searchResult.EmployeeName || ''}</td>
                <td style="${thStyle}">${searchResult.EmployeeRole || ''}</td>
            </tr>
        `;
        container.appendChild(table);
    } else {
        // No employee found
        const message = document.createElement('p');
        message.textContent = 'No employee with this ID is present.';
        container.appendChild(message);
    }

    // Add some spacing below the table or message
    const spacingDiv = document.createElement('div');
    spacingDiv.style.marginTop = '20px';
    container.appendChild(spacingDiv);

    // Add a Back button
    const backButton = document.createElement('button');
    backButton.textContent = 'Back';
    backButton.onclick = goBack;
    container.appendChild(backButton);
}

function goBack() {
    window.location.href = 'index.html';
}
