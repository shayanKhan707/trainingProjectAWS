// updateEmployee.js

function updateEmployee() {
    // Get the values from the input fields
    var eId = document.getElementById("employeeId").value;
    var employeeId = Number(eId);
    var updateKey = document.getElementById("updateKey").value;
    var updateValue = document.getElementById("updateValue").value;

    // Validate the input fields
    if (!employeeId || isNaN(employeeId)) {
        alert("Please enter a valid Employee Id");
        return;
    }

    if (!updateValue.trim()) {
        alert("Please enter values for Update Value");
        return;
    }
    if(!/^[a-zA-Z\s]+$/.test(updateValue)){
        alert("Values can  only be letter !! ");
        return;
    }

    console.log("Updating Employee with Id:", employeeId);
    console.log("Update Key:", updateKey);
    console.log("Update Value:", updateValue);

    fetch('https://a5r4kzt7n8.execute-api.us-east-1.amazonaws.com/employeemanagement/employee', {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            employeeId: employeeId,
            updateKey: updateKey,
            updateValue: updateValue,
        }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Success:', data);
        alert("Employee Record updated Successfully :) !!");
        window.location.href = 'index.html';
    })
    .catch((error) => {
        console.error('Error:', error);
        alert("Error updating employee record. Please try again.");
        window.location.href='updateEmployee.html';
    });
}

function goBack() {
    window.location.href = "index.html";
}
