
const apiEndpoint = 'https://a5r4kzt7n8.execute-api.us-east-1.amazonaws.com/employeemanagement/employees';

// Function to fetch and display employee data
function fetchAndDisplayData() {
    fetch(apiEndpoint)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // Parse response as JSON
        })
        .then(data => {
            console.log('Employee data:', data);
            populateEmployeeTable(data);
        })
        .catch(error => {
            console.error('Error fetching employee data:', error);
        });
}

// Function to populate the table with employee data
// Function to populate the table with employee data
function populateEmployeeTable(employeeData) {
    console.log('Received data:', employeeData); // Check the structure of the received data
    
    const tableBody = document.getElementById('employeeTableBody');
    tableBody.innerHTML = ''; // Clear existing content

    if (employeeData && Array.isArray(employeeData.employees) && employeeData.employees.length > 0) {
        // Records are present, populate the table
        employeeData.employees.forEach(employee => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${employee.employeeId || ''}</td>
                <td>${employee.EmployeeName || ''}</td>
                <td>${employee.EmployeeRole || ''}</td>
            `;
            tableBody.appendChild(row);
        });
    } else {
        // No records present, display a message
        const messageRow = document.createElement('tr');
        messageRow.innerHTML = '<td colspan="3" style="text-align: center;">No employees are present!!! Add employee first</td>';
        tableBody.appendChild(messageRow);
    }
}

function goBack(){
    window.location.href="index.html";
}

// Call the fetchAndDisplayData function when the page loads
window.onload = fetchAndDisplayData;